import React from 'react';
import { HelmetProvider } from 'react-helmet-async';
import { Seo } from './components/Seo';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { InsightMesh } from './components/InsightMesh';
import { Projects } from './components/Projects';
import { Contact } from './components/Contact';

function App() {
  return (
    <HelmetProvider>
      <div className="min-h-screen bg-slate-950 text-slate-50 selection:bg-violet-500/30">
        <Seo />
        <Navigation />
        
        <main>
          <Hero />
          <InsightMesh />
          <About />
          <Projects />
          <Contact />
        </main>
      </div>
    </HelmetProvider>
  );
}

export default App;